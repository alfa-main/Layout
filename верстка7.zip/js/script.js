document.querySelectorAll('.radio').forEach(function(element){
	element.onclick = bgChange;
});


function bgChange(){
    let btnlist = document.querySelectorAll('.btn__list');
    for(let i = 0; i < btnlist.length; i++){
    	btnlist[i].style.background = '#ffcc00';
    }

    let change = document.querySelectorAll('.btn__list p');
	for(let i = 0; i < change.length; i++){
		change[i].style.color = '#ba0000';
	}
}




